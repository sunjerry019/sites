Aloha Editor Demo

Demo implementation

Reset Session Store:
http://my-aloha-editor-demo.com/app/read-from-session.php?cmd=reset&pageId=0


- dont't name editable class to edit something "aloha-editable" (it's used by the core)
- class at links are removed (not so good)

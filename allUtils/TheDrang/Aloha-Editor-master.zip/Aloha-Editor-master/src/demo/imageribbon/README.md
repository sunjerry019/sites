WYSIWHAT Aloha editor experiments
=================================

This is a WYSIWHAT modified copy of the boilerplate which shows at the moment:

- Insertion of custom HTML code at the current Aloha cursor position
- Image insertion with Google Picker (Search, Picasa and your webcam)
- Video insertion with Google Picker (Search, Youtube and your webcam)

look at files:
ribbon-example.js (Menubar)
aloha-helper.js (Insert custom HTML)
gpickerdialog.js (Google Picker)

Marvin Reimer
therealmarv -at- gmail.com
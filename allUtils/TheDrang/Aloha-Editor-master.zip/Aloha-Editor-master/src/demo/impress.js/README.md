editable impress
============


inline editable impress.js with Aloha Editor.

click to edit the content of a slide.

all is stored in a session. if you want to reset it use:
http://your-install-url/app/?cmd=reset



Aloha Editor
============

The world's most advanced browser HTML5 based WYSIWYG editor lets you experience a whole new way of editing. It's faster than existing technologies and offers unprecedented WYSIWYG functionalities.

[Aloha Editor](http://Aloha-Editor.org) by @gentics





impress.js
============

It's a presentation framework based on the power of CSS3 transforms and 
transitions in modern browsers and inspired by the idea behind prezi.com.


### 0.1 ([browse](https://github.com/bartaz/impress.js/tree/0.1), [zip](https://github.com/bartaz/impress.js/zipball/0.1), [tar](https://github.com/bartaz/impress.js/tarball/0.1))

First release.

Contains basic functionality for step placement and transitions between them
with simple fallback for non-supporting browsers.


DEMO
------

[impress.js demo](http://bartaz.github.com/impress.js) by @bartaz

[What the Heck is Responsive Web Design](http://johnpolacek.github.com/WhatTheHeckIsResponsiveWebDesign-impressjs/) by John Polacek [@johnpolacek](http://twitter.com/johnpolacek)


If you have used impress.js in your presentation and would like to have it listed here,
please contact me via GitHub or send me a pull request to updated `README.md` file.


LICENSE
---------

Copyright 2011-2012 Bartek Szopka. Released under MIT License.


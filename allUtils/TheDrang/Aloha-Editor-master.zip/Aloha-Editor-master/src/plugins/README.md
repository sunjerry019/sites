# What is in this directory?

There are 5 directories

* `common`: should match Aloha-Editor's `common` plugin directory
* `extra`: should match Aloha-Editor's `extra` plugin directory
* `cnx`: contains plugins written by Connexions and are not yet used by other groups
* `oerpub`: contains plugins written by the OERPub community and are not yet used by other groups
* `oer`: contains plugins used by both Connexions and OERPub

If you would like to contribute some plugins feele free to create another directory an put your plugins in there.

define({
	"root":  {
		"button.textcolor.tooltip": "Change text color"
	},
	"de": true
});

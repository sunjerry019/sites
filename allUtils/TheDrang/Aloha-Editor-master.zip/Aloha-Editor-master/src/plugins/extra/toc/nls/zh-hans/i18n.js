define({
	"button.addtoc.tooltip": "表格内容"
});

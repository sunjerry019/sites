define({
	"headerids.label.target": "目标",
	"headerids.button.reset": "重置",
	"headerids.button.set": "设置",
	"internal_hyperlink": "内部超链接"
});

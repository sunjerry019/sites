define({
	"root":  {
		"headerids.label.target": "Target",
		"headerids.button.reset": "Reset",
		"headerids.button.set": "Set",
		"internal_hyperlink": "Internal Hyperlink"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});

define({
	"cite.button.add.quote": "将选区格式化为引语",
	"cite.button.add.blockquote": "将选区格式化为引用"
});

define({
	"root":  {
		"cite.button.add.quote": "Format selection as quote",
		"cite.button.add.blockquote": "Format selection as blockquote"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});

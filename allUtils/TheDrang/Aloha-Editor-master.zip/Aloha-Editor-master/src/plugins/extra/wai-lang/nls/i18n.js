define({
	"root":  {
		"floatingmenu.tab.wai-lang": "Language annotation",
		"button.add-wai-lang-remove.tooltip": "Remove language annotation",
		"button.add-wai-lang.tooltip": "Add language annotation"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});

define({
	"button.switch-metaview.tooltip": "Alternar entre visão meta e normal"
});

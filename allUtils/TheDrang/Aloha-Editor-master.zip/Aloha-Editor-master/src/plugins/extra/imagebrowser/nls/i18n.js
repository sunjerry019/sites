define({
	"root":  {
		"button.addimage.tooltip": "Insert Image",
		"button.removeimage.tooltip": "Remove Image",
		"newimage.defaulttext": "New Image",
		"floatingmenu.tab.img": "Image"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});

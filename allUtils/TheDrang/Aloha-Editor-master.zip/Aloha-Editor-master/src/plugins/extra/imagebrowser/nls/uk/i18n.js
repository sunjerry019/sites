define({
	"button.addimage.tooltip": "Вставити зображення",
	"button.removeimage.tooltip": "Видалити зображення",
	"newimage.defaulttext": "Нове зображення",
	"floatingmenu.tab.img": "Зображення"
});

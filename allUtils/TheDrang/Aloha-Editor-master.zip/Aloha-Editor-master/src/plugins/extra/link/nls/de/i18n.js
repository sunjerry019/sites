define( {
	'button.addlink.tooltip': 'Verweis einf\u00fcgen',
	'button.removelink.tooltip': 'Verweis entfernen',
	'newlink.defaulttext': 'Neuer Verweis',
	'floatingmenu.tab.link': 'Verweis',
	'link.target.self': '\u00D6ffnet im selben Fenster',
	'link.target.blank': '\u00D6ffnet in neuem Fenster',
	'link.target.parent': 'Parent',
	'link.target.top': 'Top',
	'link.target.framename': 'Framename',
	'link.target.legend': 'Target',
	'link.title.legend': 'Title'
} );
define({
	"floatingmenu.tab.related": "相关",
	"button.zemanta.tooltip": "Zemanta",
	"zemanta.message.shorttext": "为了找到相关的文章，图片或标签，Zemanta服务需要超过140个字符。"
});

define({
	"root":  {
		"button.formatlessPaste.tooltip": "Toggle Formatless Pasting"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});

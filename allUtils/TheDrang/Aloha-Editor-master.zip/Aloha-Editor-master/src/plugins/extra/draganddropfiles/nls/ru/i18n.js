define({
	"floatingmenu.tab.file": "Файл"
});

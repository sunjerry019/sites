define({
	"headerids.label.target": "Цел",
	"headerids.button.reset": "Ресетирај",
	"headerids.button.set": "Постави"
});

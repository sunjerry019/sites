define({
	"button.addlink.tooltip": "Insereix un enllaç",
	"button.removelink.tooltip": "Suprimeix l\'enllaç",
	"newlink.defaulttext": "Enllaç nou",
	"floatingmenu.tab.link": "Enllaç",
	"link.target.self": "Ell mateix",
	"link.target.blank": "En blanc",
	"link.target.parent": "Pare",
	"link.target.top": "Superior",
	"link.target.framename": "Nom del marc",
	"link.target.legend": "Objectiu",
	"link.title.legend": "Títol",
	"insertLink": "ctrl+k"
});

define({
	"button.toggledragdrop.tooltip": "Уклучи/Исклучи Влечи и Пушти"
});

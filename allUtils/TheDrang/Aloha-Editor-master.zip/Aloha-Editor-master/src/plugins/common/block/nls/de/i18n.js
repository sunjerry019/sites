define({
	"button.toggledragdrop.tooltip": "Drag & Drop umschalten"
});

define({
	"button.addcharacter.tooltip": "одбери специјални карактери"
});

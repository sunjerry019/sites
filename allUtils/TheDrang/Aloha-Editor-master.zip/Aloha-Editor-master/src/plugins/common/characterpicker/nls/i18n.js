define({
	"root":  {
		"button.addcharacter.tooltip": "pick special characters"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});

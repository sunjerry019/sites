define({
	"floatingmenu.tab.abbr": "Абревіатура",
	"button.addabbr.tooltip": "вставити абревіатуру",
	"button.abbr.tooltip": "форматувати як абревіатуру",
	"newabbr.defaulttext": "Абр."
});

define({
	"floatingmenu.tab.abbr": "Кратенка",
	"button.addabbr.tooltip": "внеси кратенка",
	"button.abbr.tooltip": "форматирај како кратенка",
	"newabbr.defaulttext": "Крат."
});

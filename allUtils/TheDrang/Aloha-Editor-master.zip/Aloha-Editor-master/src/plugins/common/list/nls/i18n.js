define({
	"root":  {
		"button.createulist.tooltip": "Insert Unordered List",
		"button.createolist.tooltip": "Insert Ordered List",
		"button.indentlist.tooltip": "Indent List",
		"button.outdentlist.tooltip": "Outdent List",
		"floatingmenu.tab.list": "Lists"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});

define({
	"button.alignright.tooltip": "Вирівняти справа",
	"button.alignleft.tooltip": "Вирівняти зліва",
	"button.aligncenter.tooltip": "По центру",
	"button.alignjustify.tooltip": "За форматом"
});

define({
	"button.alignright.tooltip": "Выровнять справа",
	"button.alignleft.tooltip": "Выровнять слева",
	"button.aligncenter.tooltip": "По центру",
	"button.alignjustify.tooltip": "По формату"
});

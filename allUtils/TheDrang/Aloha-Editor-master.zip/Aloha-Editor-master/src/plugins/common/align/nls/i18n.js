define({
	"root":  {
		"button.alignright.tooltip": "Align to the right",
		"button.alignleft.tooltip": "Align to the left",
		"button.aligncenter.tooltip": "Center",
		"button.alignjustify.tooltip": "Justify",
		"button.aligntop.tooltip": "Align to the top",
		"button.alignmiddle.tooltip": "Align to the middle",
		"button.alignbottom.tooltip": "Align to the bottom"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});

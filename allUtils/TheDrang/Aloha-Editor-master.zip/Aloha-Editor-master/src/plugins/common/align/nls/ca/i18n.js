define({
	"button.alignright.tooltip": "Alinea a la dreta",
	"button.alignleft.tooltip": "Alinea a l\'esquerra",
	"button.aligncenter.tooltip": "Centra",
	"button.alignjustify.tooltip": "Justifica"
});

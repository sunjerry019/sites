define({
	"button.alignright.tooltip": "Rechtsbünding",
	"button.alignleft.tooltip": "Linksbündig",
	"button.aligncenter.tooltip": "Zentriert",
	"button.alignjustify.tooltip": "Blocksatz",
	"button.aligntop.tooltip": "Oben aurichten",
	"button.alignmiddle.tooltip": "Zentriert ausrichten",
	"button.alignbottom.tooltip": "Unten ausrichten"
});

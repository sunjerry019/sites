define({
	"root":  {
		"button.addhr.tooltip": "Add a horizontal ruler"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});
